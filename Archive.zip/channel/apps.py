from django.apps import AppConfig


class ChannelConfig(AppConfig):
    name = 'channel'
